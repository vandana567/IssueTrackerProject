package com.issuetracker.test;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.service.IssueService;
import com.issuetracker.service.IssueServiceImpl;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

// Do Not Change Any Signature
public class IssueServiceTest
{
    private IssueService issueService = new IssueServiceImpl();

    @Test
    public void reportAnIssueValidTest() throws IssueTrackerException
    {
    // Your Code Goes Here
    Issue issue=new Issue("MTI-I-013-HS", "Third menu item is missing",
	                      Unit.ADMINISTRATION,LocalDate.now().minus(11, ChronoUnit.DAYS) , null, null, IssueStatus.IN_PROGRESS);
	String issueId=issueService.reportAnIssue(issue);
	Assertions.assertEquals("MTI-I-013-HS", issueId);
    }

    @Test
    public void reportAnIssueInvalidReportedDateTest()
    {
    // Your Code Goes Here
    Issue issue=new Issue("MTI-I-013-HS", "Third menu item is missing",
	                      Unit.ADMINISTRATION,LocalDate.now().plus(5, ChronoUnit.DAYS) , null, null, IssueStatus.IN_PROGRESS);
	IssueTrackerException dateException=Assertions.assertThrows(IssueTrackerException.class, ()->issueService.reportAnIssue(issue));
	Assertions.assertEquals("Validator.INVALID_REPORTED_DATE", dateException.getMessage());
    }


    @Test
    public void reportAnIssueInvalidStatusTest()
    {
    // Your Code Goes Here
    Issue issue=new Issue("MTI-I-013-HS", "Third menu item is missing",
	                      Unit.ADMINISTRATION,LocalDate.now().minus(11, ChronoUnit.DAYS) , null, null, IssueStatus.CLOSED);
	IssueTrackerException dateException=Assertions.assertThrows(IssueTrackerException.class, ()->issueService.reportAnIssue(issue));
	Assertions.assertEquals("Validator.INVALID_STATUS", dateException.getMessage());
    }


    @Test
    public void reportAnIssueDuplicateIssueIdTest()
    {
    // Your Code Goes Here
    Issue issue=new Issue("MTI-I-001-HS", "Third menu item is missing",
	                      Unit.ADMINISTRATION,LocalDate.now().minus(11, ChronoUnit.DAYS) , null, null, IssueStatus.IN_PROGRESS);
	IssueTrackerException exception=Assertions.assertThrows(IssueTrackerException.class, ()->issueService.reportAnIssue(issue));
	Assertions.assertEquals("IssueService.DUPLICATE_ISSUE_ID", exception.getMessage() );
    }
}
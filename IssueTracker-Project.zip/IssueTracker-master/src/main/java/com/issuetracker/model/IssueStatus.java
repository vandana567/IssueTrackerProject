package com.issuetracker.model;

// Do Not Change Any Signature
public enum IssueStatus
{
    // Your Code Goes Here
    OPEN,
    IN_PROGRESS,
    CLOSED,
    RESOLVED,
    RECALLED
}
package com.issuetracker.validator;

import java.time.LocalDate;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;

// Do Not Change Any Signature
public class Validator
{
    public void validate(Issue issue) throws IssueTrackerException
    {
        // Your Code Goes Here
        try{
                if(!isValidIssueId(issue.getIssueId())) {
                throw new IssueTrackerException("Validator.INVALID_ISSUE_ID");
                }
                if(!isValidIssueDescription(issue.getIssueDescription())) {
                throw new IssueTrackerException("Validator.INVALID_ISSUE_DESCRIPTION");
                }
                if(!isValidReportedOn(issue.getReportedOn())) {
                throw new IssueTrackerException("Validator.INVALID_REPORTED_DATE");
                }
                if(!isValidStatus(issue.getStatus())) {
                throw new IssueTrackerException("Validator.INVALID_STATUS");
                }
            }catch(IssueTrackerException e) {
                // TODO: handle exception
                LogFactory.getLog(getClass()).error(e.getMessage(),e);
                throw e;
           }
    
    }

    public Boolean isValidIssueId(String issueId)
    {
        // Your Code Goes Here
        if(issueId==null)
            return false;
        String regex = "(MTI)-(I)-(([0-9]{2}[1-9])|([1-9][0-9]{2})|([0-9][1-9][0-9]))-(LS|MS|HS)";
        if(issueId.matches(regex))
            return true;
        return false;
    }

    public Boolean isValidIssueDescription(String issueDescription)
    {
        // Your Code Goes Here
        if(issueDescription==null || issueDescription.isBlank())
	        return false;
        if(!issueDescription.trim().equals(issueDescription) || issueDescription.length()>50)
	        return false;
        String regex="([A-Za-z]+[\\s]?)+";
        if(issueDescription.matches(regex))
	        return true;
	    return false;
    }

    public Boolean isValidReportedOn(LocalDate reportedOn)
    {
        // Your Code Goes Here
        if(reportedOn==null) 
            return false;
        if(reportedOn.isBefore(LocalDate.now()))
	        return true;
        if(reportedOn.equals(LocalDate.now()))
            return true;
        return false;
    }

    public Boolean isValidStatus(IssueStatus status)
    {
        if(status==null) return false;
        if(status==IssueStatus.OPEN || status==IssueStatus.IN_PROGRESS)
            return true;
        return false;
    }
}
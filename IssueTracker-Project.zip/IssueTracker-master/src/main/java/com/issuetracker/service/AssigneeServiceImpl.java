package com.issuetracker.service;

import java.util.List;

import com.issuetracker.dao.AssigneeDAO;
import com.issuetracker.model.Assignee;
import com.issuetracker.model.Unit;

// Do Not Change Any Signature
public class AssigneeServiceImpl implements AssigneeService
{
    private AssigneeDAO assigneeDAO = new AssigneeDAOImpl();

    @Override
    public List<Assignee> fetchAssignee(Unit unit)
    {
        // Your Code Goes Here
        List<Assignee> receivedAssignees= assigneeDAO.fetchAssignees(unit);
        return receivedAssignees.stream().
                                filter(assignee->assignee.getNumberOfIssuesActive()<3)
                                .collect(Collectors.toList());
    }

    @Override
    public void updateActiveIssueCount(String assigneeEmail,
				       Character operation)
    {
        // Your Code Goes Here
        Assignee assignee=assigneeDAO.getAssigneeByEmail(assigneeEmail);
        switch(operation) {
            case'I':
                assignee.setNumberOfIssuesActive(assignee.getNumberOfIssuesActive()+1);
                break;
            case'D':
                assignee.setNumberOfIssuesActive(assignee.getNumberOfIssuesActive()-1);
                break;
        }
    }
}
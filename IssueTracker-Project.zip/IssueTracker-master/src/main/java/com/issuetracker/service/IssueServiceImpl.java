package com.issuetracker.service;

import java.util.List;
import java.util.Map;

import com.issuetracker.dao.IssueDAO;
import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueReport;
import com.issuetracker.model.IssueStatus;
import com.issuetracker.validator.Validator;

// Do Not Change Any Signature
public class IssueServiceImpl implements IssueService
{
    private AssigneeService assigneeService=new AssigneeServiceImpl();
    private IssueDAO issueDAO=new IssueDAOImpl();
    private Validator validator=new Validator();

    @Override
    public String reportAnIssue(Issue issue) throws IssueTrackerException
    {
        // Your Code Goes Here
        try {
            validator.validate(issue);
            List<Assignee> receivedAssignees=assigneeService.fetchAssignee(issue.getIssueUnit());
            if(!receivedAssignees.isEmpty()) {
               Assignee first=receivedAssignees.get(0);
               issue.setAssigneeEmail(first.getAssigneeEmail());
               assigneeService.updateActiveIssueCount(first.getAssigneeEmail(), 'I');
             
            }
            String receivedIssueId = issueDAO.reportAnIssue(issue);
            if(receivedIssueId==null) {
                throw new IssueTrackerException("IssueService.DUPLICATE_ISSUE_ID");	    
            }
            return receivedIssueId;
            }catch (IssueTrackerException e) {
                // TODO: handle exception
                if(e.getMessage().contains("IssueService"))
                LogFactory.getLog(getClass()).error(e.getMessage(), e);
                throw e;
            }
    }

    @Override
    public Boolean updateStatus(String issueId,
				IssueStatus status) throws IssueTrackerException
    {
        // Your Code Goes Here
        try {
            Issue receivedIssue = issueDAO.getIssueById(issueId);
            if(receivedIssue==null) {
                throw new IssueTrackerException("IssueService.ISSUE_NOT_FOUND");
            }
            if(status==receivedIssue.getStatus()) {
                throw new IssueTrackerException("IssueService.NO_STATUS_CHANGE");
            }
            if(status==IssueStatus.RECALLED && receivedIssue.getStatus()!=IssueStatus.OPEN) {
                throw new IssueTrackerException("IssueService.INCOMPATIBLE_STATUS");
            }
            issueDAO.updateStatus(receivedIssue, status);
            if (!(IssueStatus.OPEN.equals(status)
                      || IssueStatus.IN_PROGRESS.equals(status))) {
                assigneeService.updateActiveIssueCount(receivedIssue.getAssigneeEmail(), 'D');
            }
            return true;
            }catch (IssueTrackerException e) {
                // TODO: handle exception
                if(e.getMessage().contains("IssueService"))
                LogFactory.getLog(getClass()).error(e.getMessage(), e);
                throw e;
            }
    }

    @Override
    public List<IssueReport> showIssues(Map<Character, Object> filterCriteria) throws IssueTrackerException
    {
        // Your Code Goes Here
        try {
            List<Issue> receivedList=issueDAO.getIssueList();
            List<Issue> filterIssues=new ArrayList<Issue>();
            for(Character c:filterCriteria.keySet()) {
               if(c=='A') {
                   
                    filterIssues=receivedList.stream()
                                       .filter(issue-> issue.getAssigneeEmail()!=null && issue.getAssigneeEmail().equals(filterCriteria.get(c)))
                                       .collect(Collectors.toList());
               }
               else if(c=='S') {
                    filterIssues=receivedList.stream()
                                       .filter(issue->issue.getStatus().equals(filterCriteria.get(c)))
                                       .collect(Collectors.toList());
               }
            }
            
            if(filterIssues.isEmpty()) {
                throw new IssueTrackerException("IssueService.NO_ISSUES_FOUND");
            }
            
            Iterator<Issue> itr=filterIssues.iterator();
            List<IssueReport> finalList=new ArrayList<IssueReport>();
            while(itr.hasNext()) {
                Issue tempIssue=itr.next();
                finalList.add(new IssueReport(tempIssue.getIssueId(), tempIssue.getIssueDescription(), tempIssue.getAssigneeEmail(), tempIssue.getStatus()));
            }
            
        
            return finalList;
            }catch (IssueTrackerException e) {
                // TODO: handle exception
                if(e.getMessage().contains("IssueService"))
                LogFactory.getLog(getClass()).error(e.getMessage(), e);
                throw e;
            }
    }

    @Override
    public List<Issue> deleteIssues() throws IssueTrackerException
    {
        // Your Code Goes Here
        try {
                List<Issue> recieveList=issueDAO.getIssueList();
                List<Issue> newList=new ArrayList<Issue>();
                Iterator<Issue> itr=recieveList.iterator();
                while(itr.hasNext()) {
                    Issue tempIssue=itr.next();
                    if((tempIssue.getStatus().equals(IssueStatus.RESOLVED)|| tempIssue.getStatus().equals(IssueStatus.CLOSED)) && ChronoUnit.DAYS.between(tempIssue.getUpdatedOn(),LocalDate.now())>=14) {
                    newList.add(tempIssue);
                    }
                }
                
                if(newList.isEmpty()) {
                    throw new IssueTrackerException("IssueSerivce.NO_ISSUES_DELETED");
                }
            
                return newList;
            }catch (IssueTrackerException e) {
            // TODO: handle exception
            if(e.getMessage().contains("IssueService"))
                LogFactory.getLog(getClass()).error(e.getMessage(), e);
                throw e;
            }
    }
}